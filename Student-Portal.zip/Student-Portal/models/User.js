const bcrypt = require('bcryptjs');

// In-memory user store
const users = [];
let nextId = 1;

// Create a new user
const createUser = async ({ name, email, password, role, department }) => {
  const salt = await bcrypt.genSalt(10);
  const hashedPassword = await bcrypt.hash(password, salt);

  const user = {
    id: nextId++,
    name,
    email: email.toLowerCase(),
    password: hashedPassword,
    role: role || 'student',       // student | faculty | admin
    department: department || '',
    createdAt: new Date().toISOString()
  };

  users.push(user);
  return sanitize(user);
};

// Find user by email (returns full record including password)
const findByEmail = (email) => {
  return users.find((u) => u.email === email.toLowerCase()) || null;
};

// Find user by ID (returns full record including password)
const findById = (id) => {
  return users.find((u) => u.id === id) || null;
};

// Get all students
const getAllStudents = () => {
  return users.filter((u) => u.role === 'student').map(sanitize);
};

// Get all users (admin)
const getAllUsers = () => {
  return users.map(sanitize);
};

// Update a user by ID
const updateUser = (id, updates) => {
  const user = users.find((u) => u.id === id);
  if (!user) return null;

  const allowedFields = ['name', 'department', 'email'];
  allowedFields.forEach((field) => {
    if (updates[field] !== undefined) {
      user[field] = field === 'email' ? updates[field].toLowerCase() : updates[field];
    }
  });

  return sanitize(user);
};

// Delete a user by ID
const deleteUser = (id) => {
  const index = users.findIndex((u) => u.id === id);
  if (index === -1) return false;
  users.splice(index, 1);
  return true;
};

// Strip password from user object
const sanitize = (user) => {
  const { password, ...safe } = user;
  return safe;
};

module.exports = {
  createUser,
  findByEmail,
  findById,
  getAllStudents,
  getAllUsers,
  updateUser,
  deleteUser,
  sanitize
};
