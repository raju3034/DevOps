const API = '';  // same origin

let token = null;
let currentUser = null;

// ── Helpers ──────────────────────────────────────────
async function api(path, opts = {}) {
    const headers = { 'Content-Type': 'application/json' };
    if (token) headers['Authorization'] = `Bearer ${token}`;
    const res = await fetch(API + path, { ...opts, headers });
    const data = await res.json();
    if (!res.ok) throw new Error(data.message || 'Request failed');
    return data;
}

function toast(msg, type = 'info') {
    const el = document.getElementById('toast');
    el.textContent = msg;
    el.className = `toast ${type}`;
    setTimeout(() => el.className = 'toast hidden', 3000);
}

// ── Tab switching ────────────────────────────────────
function showTab(tab) {
    document.getElementById('loginForm').classList.toggle('hidden', tab !== 'login');
    document.getElementById('registerForm').classList.toggle('hidden', tab !== 'register');
    document.getElementById('loginTab').classList.toggle('active', tab === 'login');
    document.getElementById('registerTab').classList.toggle('active', tab === 'register');
}

// ── Auth ─────────────────────────────────────────────
async function handleLogin(e) {
    e.preventDefault();
    try {
        const email = document.getElementById('loginEmail').value;
        const password = document.getElementById('loginPassword').value;
        const data = await api('/api/auth/login', {
            method: 'POST',
            body: JSON.stringify({ email, password })
        });
        token = data.token;
        currentUser = data.data;
        toast('Login successful!', 'success');
        showDashboard();
    } catch (err) {
        toast(err.message, 'error');
    }
}

async function handleRegister(e) {
    e.preventDefault();
    try {
        const body = {
            name: document.getElementById('regName').value,
            email: document.getElementById('regEmail').value,
            password: document.getElementById('regPassword').value,
            role: document.getElementById('regRole').value,
            department: document.getElementById('regDept').value
        };
        await api('/api/auth/register', { method: 'POST', body: JSON.stringify(body) });
        toast('Account created! Please login.', 'success');
        showTab('login');
    } catch (err) {
        toast(err.message, 'error');
    }
}

function logout() {
    token = null;
    currentUser = null;
    document.getElementById('authSection').classList.remove('hidden');
    document.getElementById('dashboardSection').classList.add('hidden');
    document.getElementById('navLinks').innerHTML = '';
    toast('Logged out', 'info');
}

// ── Dashboard ────────────────────────────────────────
async function showDashboard() {
    document.getElementById('authSection').classList.add('hidden');
    document.getElementById('dashboardSection').classList.remove('hidden');

    // Nav
    document.getElementById('navLinks').innerHTML = `
    <span class="nav-user">${currentUser.email}</span>
    <button class="btn btn-sm btn-logout" onclick="logout()">Logout</button>
  `;

    // Profile
    loadProfile();
    loadStudents();

    if (currentUser.role === 'admin') {
        document.getElementById('usersCard').classList.remove('hidden');
        loadAllUsers();
    } else {
        document.getElementById('usersCard').classList.add('hidden');
    }
}

async function loadProfile() {
    try {
        const { data } = await api('/api/profile');
        currentUser = data;
        document.getElementById('avatarInitial').textContent = data.name.charAt(0).toUpperCase();
        document.getElementById('profileName').textContent = data.name;
        document.getElementById('profileEmail').textContent = data.email;
        document.getElementById('profileDept').textContent = data.department || '—';
        document.getElementById('profileId').textContent = `#${data.id}`;

        const roleEl = document.getElementById('profileRole');
        roleEl.textContent = data.role;
        roleEl.className = `badge badge-${data.role}`;
    } catch (err) {
        toast(err.message, 'error');
    }
}

// ── Students ─────────────────────────────────────────
async function loadStudents() {
    try {
        const { data } = await api('/api/students');
        document.getElementById('studentCount').textContent = data.length;
        const tbody = document.getElementById('studentsBody');
        tbody.innerHTML = data.map(s => `
      <tr>
        <td>${s.id}</td>
        <td>${s.name}</td>
        <td>${s.email}</td>
        <td>${s.department || '—'}</td>
        <td class="actions">
          ${canEdit(s) ? `<button class="btn btn-sm btn-primary" onclick="openEdit(${s.id},'${esc(s.name)}','${esc(s.department)}')">Edit</button>` : '—'}
        </td>
      </tr>
    `).join('');
    } catch (err) {
        toast(err.message, 'error');
    }
}

function canEdit(student) {
    if (currentUser.role === 'admin' || currentUser.role === 'faculty') return true;
    return currentUser.id === student.id;
}

function esc(str) {
    return (str || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
}

// ── Edit modal ───────────────────────────────────────
function openEdit(id, name, dept) {
    document.getElementById('editId').value = id;
    document.getElementById('editName').value = name;
    document.getElementById('editDept').value = dept;
    document.getElementById('editModal').classList.remove('hidden');
}
function closeModal() {
    document.getElementById('editModal').classList.add('hidden');
}

async function handleUpdate(e) {
    e.preventDefault();
    const id = document.getElementById('editId').value;
    const body = {
        name: document.getElementById('editName').value,
        department: document.getElementById('editDept').value
    };
    try {
        await api(`/api/students/${id}`, { method: 'PUT', body: JSON.stringify(body) });
        toast('Student updated!', 'success');
        closeModal();
        loadProfile();
        loadStudents();
    } catch (err) {
        toast(err.message, 'error');
    }
}

// ── Admin: All Users ─────────────────────────────────
async function loadAllUsers() {
    try {
        const { data } = await api('/api/users');
        document.getElementById('userCount').textContent = data.length;
        const tbody = document.getElementById('usersBody');
        tbody.innerHTML = data.map(u => `
      <tr>
        <td>${u.id}</td>
        <td>${u.name}</td>
        <td>${u.email}</td>
        <td><span class="badge badge-${u.role}">${u.role}</span></td>
        <td>${u.department || '—'}</td>
        <td class="actions">
          ${u.id !== currentUser.id ? `<button class="btn btn-sm btn-danger" onclick="deleteUser(${u.id})">Delete</button>` : '—'}
        </td>
      </tr>
    `).join('');
    } catch (err) {
        toast(err.message, 'error');
    }
}

async function deleteUser(id) {
    if (!confirm('Delete this user?')) return;
    try {
        await api(`/api/users/${id}`, { method: 'DELETE' });
        toast('User deleted', 'success');
        loadAllUsers();
        loadStudents();
    } catch (err) {
        toast(err.message, 'error');
    }
}
