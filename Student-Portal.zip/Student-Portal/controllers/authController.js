const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const User = require('../models/User');

// ------------------------------------------------------------------
// POST /api/auth/register
// ------------------------------------------------------------------
const register = async (req, res) => {
    try {
        const { name, email, password, role, department } = req.body;

        // Validate required fields
        if (!name || !email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide name, email, and password.'
            });
        }

        // Validate email format
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailRegex.test(email)) {
            return res.status(400).json({
                success: false,
                message: 'Please provide a valid email address.'
            });
        }

        // Validate password length
        if (password.length < 6) {
            return res.status(400).json({
                success: false,
                message: 'Password must be at least 6 characters long.'
            });
        }

        // Check email uniqueness
        const existingUser = User.findByEmail(email);
        if (existingUser) {
            return res.status(409).json({
                success: false,
                message: 'A user with this email already exists.'
            });
        }

        // Validate role
        const validRoles = ['student', 'faculty', 'admin'];
        if (role && !validRoles.includes(role)) {
            return res.status(400).json({
                success: false,
                message: `Invalid role. Must be one of: ${validRoles.join(', ')}`
            });
        }

        const user = await User.createUser({ name, email, password, role, department });

        res.status(201).json({
            success: true,
            message: 'User registered successfully.',
            data: user
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Server error.',
            error: err.message
        });
    }
};

// ------------------------------------------------------------------
// POST /api/auth/login
// ------------------------------------------------------------------
const login = async (req, res) => {
    try {
        const { email, password } = req.body;

        // Validate required fields
        if (!email || !password) {
            return res.status(400).json({
                success: false,
                message: 'Please provide email and password.'
            });
        }

        // Find user
        const user = User.findByEmail(email);
        if (!user) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        // Compare password
        const isMatch = await bcrypt.compare(password, user.password);
        if (!isMatch) {
            return res.status(401).json({
                success: false,
                message: 'Invalid email or password.'
            });
        }

        // Generate JWT
        const payload = {
            id: user.id,
            email: user.email,
            role: user.role
        };

        const token = jwt.sign(payload, process.env.JWT_SECRET, {
            expiresIn: process.env.JWT_EXPIRES_IN || '1h'
        });

        // Log JWT token to terminal
        console.log('\n========== LOGIN SUCCESSFUL ==========');
        console.log('User  :', user.name, `(${user.role})`);
        console.log('Email :', user.email);
        console.log('Token :', token);
        console.log('=======================================\n');

        res.status(200).json({
            success: true,
            message: 'Login successful.',
            token,
            data: User.sanitize(user)
        });
    } catch (err) {
        res.status(500).json({
            success: false,
            message: 'Server error.',
            error: err.message
        });
    }
};

module.exports = { register, login };
