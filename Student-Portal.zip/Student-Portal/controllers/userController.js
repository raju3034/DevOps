const User = require('../models/User');

// ------------------------------------------------------------------
// GET /api/profile — View own profile (any authenticated user)
// ------------------------------------------------------------------
const getProfile = (req, res) => {
    const user = User.findById(req.user.id);
    if (!user) {
        return res.status(404).json({
            success: false,
            message: 'User not found.'
        });
    }

    res.status(200).json({
        success: true,
        data: User.sanitize(user)
    });
};

// ------------------------------------------------------------------
// GET /api/students — View student information
//   Student  → sees only their own record (if they are a student)
//   Faculty / Admin → sees all student records
// ------------------------------------------------------------------
const getStudents = (req, res) => {
    if (req.user.role === 'student') {
        const user = User.findById(req.user.id);
        if (!user) {
            return res.status(404).json({ success: false, message: 'User not found.' });
        }
        return res.status(200).json({
            success: true,
            data: [User.sanitize(user)]
        });
    }

    // Faculty or Admin
    const students = User.getAllStudents();
    res.status(200).json({
        success: true,
        count: students.length,
        data: students
    });
};

// ------------------------------------------------------------------
// PUT /api/students/:id — Update student information
//   Student  → can update only their own record
//   Faculty / Admin → can update any student record
// ------------------------------------------------------------------
const updateStudent = (req, res) => {
    const targetId = parseInt(req.params.id, 10);

    // Students can only update themselves
    if (req.user.role === 'student' && req.user.id !== targetId) {
        return res.status(403).json({
            success: false,
            message: 'Access denied. You can only update your own record.'
        });
    }

    const targetUser = User.findById(targetId);
    if (!targetUser) {
        return res.status(404).json({
            success: false,
            message: 'Student not found.'
        });
    }

    // Faculty can only update students
    if (req.user.role === 'faculty' && targetUser.role !== 'student') {
        return res.status(403).json({
            success: false,
            message: 'Faculty can only update student records.'
        });
    }

    const updated = User.updateUser(targetId, req.body);
    res.status(200).json({
        success: true,
        message: 'Student record updated successfully.',
        data: updated
    });
};

// ------------------------------------------------------------------
// GET /api/users — List all users (Admin only)
// ------------------------------------------------------------------
const getAllUsers = (req, res) => {
    const users = User.getAllUsers();
    res.status(200).json({
        success: true,
        count: users.length,
        data: users
    });
};

// ------------------------------------------------------------------
// DELETE /api/users/:id — Delete a user (Admin only)
// ------------------------------------------------------------------
const deleteUser = (req, res) => {
    const targetId = parseInt(req.params.id, 10);

    const deleted = User.deleteUser(targetId);
    if (!deleted) {
        return res.status(404).json({
            success: false,
            message: 'User not found.'
        });
    }

    res.status(200).json({
        success: true,
        message: 'User deleted successfully.'
    });
};

module.exports = { getProfile, getStudents, updateStudent, getAllUsers, deleteUser };
