const express = require('express');
const router = express.Router();
const { authenticate, authorize } = require('../middleware/auth');
const {
    getProfile,
    getStudents,
    updateStudent,
    getAllUsers,
    deleteUser
} = require('../controllers/userController');

// All routes below require authentication
router.use(authenticate);

// GET /api/profile — View own profile (any authenticated user)
router.get('/profile', getProfile);

// GET /api/students — View student information
router.get('/students', getStudents);

// PUT /api/students/:id — Update student record (Faculty & Admin, or own record for Students)
router.put('/students/:id', updateStudent);

// GET /api/users — List all users (Admin only)
router.get('/users', authorize('admin'), getAllUsers);

// DELETE /api/users/:id — Delete a user (Admin only)
router.delete('/users/:id', authorize('admin'), deleteUser);

module.exports = router;
